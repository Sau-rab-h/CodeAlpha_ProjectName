import streamlit as st
from deep_translator import GoogleTranslator

st.title("🌐 Language Translation Tool")

text = st.text_area("Enter text to translate:")

src_lang = st.text_input("Source Language (default 'auto'):", "auto")
dest_lang = st.text_input("Target Language (e.g., 'hi' for Hindi):", "hi")

if st.button("Translate"):
    if text.strip():
        try:
            translated = GoogleTranslator(source=src_lang, target=dest_lang).translate(text)
            st.success(f"✅ Translated Text: {translated}")
        except Exception as e:
            st.error(f"Error: {e}")
    else:
        st.warning("Please enter some text first!")
