# 🌐 Language Translation Tool

This is **Task 1** of the CodeAlpha Artificial Intelligence Internship.  
A simple **Language Translation Web App** built with **Streamlit** and **Deep Translator**.

---

## 🚀 Features
- Translate text between multiple languages
- Auto-detect source language
- Simple, user-friendly Streamlit interface
- Works with Python 3.13

---

## 📂 Project Structure
