import streamlit as st
import numpy as np
import music21 as m21
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Activation
import os

st.title("🎵 AI Music Generator (Task 3 - CodeAlpha)")

st.write("Upload MIDI files, train an LSTM model, and generate new melodies!")

# Create output folder if not exists
os.makedirs("output", exist_ok=True)

# Parameters
SEQUENCE_LENGTH = 20

uploaded_files = st.file_uploader("Upload MIDI files", type=["mid", "midi"], accept_multiple_files=True)

notes = []

# ✅ Preprocess MIDI files
if uploaded_files:
    for file in uploaded_files:
        mf = m21.converter.parse(file)
        for element in mf.flat.notes:
            if isinstance(element, m21.note.Note):
                notes.append(str(element.pitch))
            elif isinstance(element, m21.chord.Chord):
                notes.append('.'.join(str(n) for n in element.normalOrder))

    st.success(f"Extracted {len(notes)} notes from uploaded files.")

# Prepare dataset for training
def prepare_sequences(notes, seq_len):
    pitchnames = sorted(set(notes))
    note_to_int = dict((note, number) for number, note in enumerate(pitchnames))

    network_input = []
    network_output = []

    for i in range(len(notes) - seq_len):
        seq_in = notes[i:i + seq_len]
        seq_out = notes[i + seq_len]
        network_input.append([note_to_int[char] for char in seq_in])
        network_output.append(note_to_int[seq_out])

    n_patterns = len(network_input)

    X = np.reshape(network_input, (n_patterns, seq_len, 1))
    X = X / float(len(pitchnames))
    y = np.array(network_output)

    return X, y, note_to_int, pitchnames

if st.button("Train Model"):
    if len(notes) > SEQUENCE_LENGTH:
        X, y, note_to_int, pitchnames = prepare_sequences(notes, SEQUENCE_LENGTH)

        model = Sequential()
        model.add(LSTM(128, input_shape=(X.shape[1], X.shape[2])))
        model.add(Dense(64, activation="relu"))
        model.add(Dense(len(pitchnames), activation="softmax"))

        model.compile(loss="sparse_categorical_crossentropy", optimizer="adam")
        st.info("Training started... (for demo, training is minimal)")
        model.fit(X, y, epochs=5, batch_size=64, verbose=1)

        st.success("✅ Model training complete. Ready to generate music!")

        # Save model for generation
        model.save("output/music_model.h5")
    else:
        st.warning("Upload more MIDI data for training!")

if st.button("Generate Music"):
    if os.path.exists("output/music_model.h5") and len(notes) > SEQUENCE_LENGTH:
        X, y, note_to_int, pitchnames = prepare_sequences(notes, SEQUENCE_LENGTH)
        int_to_note = dict((number, note) for number, note in enumerate(pitchnames))

        # Start from a random pattern
        start = np.random.randint(0, len(X)-1)
        pattern = X[start]

        prediction_output = []

        # Generate 50 notes
        for _ in range(50):
            prediction_input = np.reshape(pattern, (1, SEQUENCE_LENGTH, 1))
            prediction_input = prediction_input / float(len(pitchnames))

            prediction = model.predict(prediction_input, verbose=0)
            index = np.argmax(prediction)
            result = int_to_note[index]
            prediction_output.append(result)

            # Update pattern
            pattern = np.append(pattern, index)
            pattern = pattern[1:]
            pattern = np.reshape(pattern, (SEQUENCE_LENGTH, 1))

        # Convert notes to MIDI
        offset = 0
        output_notes = []

        for pattern in prediction_output:
            if '.' in pattern or pattern.isdigit():
                chord_notes = pattern.split('.')
                chord_notes = [m21.note.Note(int(n)) for n in chord_notes]
                for n in chord_notes:
                    n.storedInstrument = m21.instrument.Piano()
                chord = m21.chord.Chord(chord_notes)
                chord.offset = offset
                output_notes.append(chord)
            else:
                note = m21.note.Note(pattern)
                note.offset = offset
                note.storedInstrument = m21.instrument.Piano()
                output_notes.append(note)

            offset += 0.5

        midi_stream = m21.stream.Stream(output_notes)
        midi_file = "output/generated_music.mid"
        midi_stream.write("midi", fp=midi_file)

        st.success(f"🎶 Music generated and saved at {midi_file}")
    else:
        st.warning("Please train the model first or upload more MIDI data.")
