# 🎵 Music Generation with AI

This is **Task 3** of the CodeAlpha Artificial Intelligence Internship.  
An AI-powered music generator that uses an **LSTM neural network** trained on MIDI data to create new melodies.

---

## 🚀 Features
- Upload MIDI files as training data
- Preprocess notes and chords using `music21`
- Train a simple **LSTM model** on music sequences
- Generate new music and save it as `.mid`
- Web-based interface using Streamlit

---

## 📂 Project Structure
