import streamlit as st
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np

# ✅ Sample FAQ dataset
faqs = {
    "What is CodeAlpha?": "CodeAlpha is a software development and internship company.",
    "How can I apply for internship?": "You can apply via CodeAlpha's official website.",
    "Will I get a certificate?": "Yes, a QR-verified certificate is issued after successful completion.",
    "Is the internship online?": "Yes, the internship is 100% online and remote.",
    "Do I need prior experience?": "No, beginners can also apply and learn through the projects."
}

# Prepare data
questions = list(faqs.keys())
answers = list(faqs.values())

vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(questions)

# 🌟 Streamlit UI
st.title("🤖 FAQ Chatbot")
st.write("Ask your question below and I’ll try to find the best answer!")

# User input
user_query = st.text_input("Your Question:")

if st.button("Get Answer"):
    if user_query.strip():
        # Convert user query into vector
        user_vec = vectorizer.transform([user_query])

        # Compute similarity
        similarities = cosine_similarity(user_vec, X).flatten()
        best_match = np.argmax(similarities)
        confidence = similarities[best_match]

        # Threshold to avoid nonsense answers
        if confidence > 0.3:
            st.success(answers[best_match])
        else:
            st.warning("❌ Sorry, I don't know the answer.")
    else:
        st.warning("Please enter a question first!")
