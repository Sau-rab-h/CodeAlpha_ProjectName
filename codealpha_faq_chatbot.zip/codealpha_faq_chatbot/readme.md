# 🤖 FAQ Chatbot

A simple **FAQ Chatbot** built with **Streamlit**, **NLTK**, and **Scikit-learn** for the CodeAlpha Internship.

## 🚀 Features
- Ask questions in natural language
- Bot finds the closest matching FAQ
- Uses TF-IDF + Cosine Similarity for intent matching
- Simple chat-style UI with Streamlit

## 📦 Installation
1. Clone the repo:
   ```bash
   git clone https://github.com/yourusername/CodeAlpha_FAQChatbot.git
   cd CodeAlpha_FAQChatbot
